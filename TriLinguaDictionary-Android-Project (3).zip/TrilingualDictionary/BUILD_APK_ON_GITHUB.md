# Build the APK using GitHub Actions

This project includes `.github/workflows/build-apk.yml` to build the installable debug APK on a GitHub-hosted Android/Java build runner.

1. Create a new GitHub repository and upload the contents of this project (the `TrilingualDictionary` folder contents, not the parent folder).
2. Open the repository's **Actions** tab and select **Build TriLingua Android APK**.
3. Select **Run workflow**. Wait for the workflow to finish successfully.
4. Open the completed workflow run and download the `TriLinguaDictionary-debug-apk` artifact. Extract it to get `app-debug.apk`.
5. Transfer `app-debug.apk` to your Android phone and install it. Android may ask you to allow installs from the app you use to open the APK.

The APK is a debug build for testing, not a Play Store release. A signed release build should be prepared separately before public distribution.
