package com.pixxelart.trilingualdictionary;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private final ExecutorService executor = Executors.newFixedThreadPool(2);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setTextZoom(100);
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new DictionaryBridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class DictionaryBridge {
        @JavascriptInterface public void translate(String text, String from, String to, String requestId) {
            executor.execute(() -> {
                String result;
                HttpURLConnection connection = null;
                try {
                    String q = URLEncoder.encode(text, "UTF-8");
                    URL url = new URL("https://api.mymemory.translated.net/get?q=" + q + "&langpair=" + from + "%7C" + to);
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(9000);
                    connection.setReadTimeout(12000);
                    connection.setRequestProperty("User-Agent", "TriLinguaDictionary/1.0");
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8));
                    StringBuilder body = new StringBuilder(); String line;
                    while ((line = reader.readLine()) != null) body.append(line);
                    reader.close();
                    JSONObject json = new JSONObject(body.toString());
                    JSONObject response = json.optJSONObject("responseData");
                    result = response == null ? "" : response.optString("translatedText", "");
                } catch (Exception e) { result = ""; }
                finally { if (connection != null) connection.disconnect(); }
                final String safe = JSONObject.quote(result);
                runOnUiThread(() -> webView.evaluateJavascript("window.onTranslationResult(" + JSONObject.quote(requestId) + "," + safe + ")", null));
            });
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() { executor.shutdownNow(); super.onDestroy(); }
}
