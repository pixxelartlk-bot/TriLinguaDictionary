# TriLingua Dictionary (Android)

A starter Android app for English ↔ Sinhala ↔ Tamil word lookup, with an offline starter vocabulary and online translation fallback. The visual identity uses a neutral typographic “T” mark; it does not use Sri Lankan national logos, flags, emblems, or government insignia.

## Build the APK
1. Install **Android Studio** (current stable) on Windows/macOS/Linux.
2. Open this `TrilingualDictionary` folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio creates the APK under `app/build/outputs/apk/debug/app-debug.apk`.
6. Copy the APK to your Android phone and install it. You may need to allow installation from that file manager.

## Features in this starter
- Search words in English, Sinhala, or Tamil.
- Display translations in the other two languages.
- Offline starter vocabulary embedded in the app.
- Online translation fallback through MyMemory Translation API.
- Text-to-speech using voices installed on the Android device.
- Responsive mobile interface; no account required.

## Important limitations
- The offline dictionary currently contains a small starter vocabulary, not a complete dictionary. Add vetted entries to the `WORDS` array in `app/src/main/assets/index.html` to expand offline coverage.
- Online translation depends on internet access and the availability/quality of the public MyMemory service. It is not guaranteed to return a result for every language pair.
- Sinhala/Tamil speech depends on the Android device having the relevant TTS voice installed.
- This is an unsigned debug APK build workflow. A Play Store release requires a signed release build and privacy/data disclosures appropriate to the final service.

## Technical notes
- Native Android shell: Java + WebView.
- Min Android version: Android 6.0 (API 23).
- Online lookup is performed in Android Java, not directly from the page, to avoid browser cross-origin restrictions.
- Package: `com.pixxelart.trilingualdictionary`.
